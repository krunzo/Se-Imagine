Os MP3 originais e finais aprovados permanecem intactos no projeto. Hashes em inspecao_fontes.json. Backup documental: /workspace/backups_dublagem/antes_premix_20261104T033624Z.tar.gz
O backup integral de áudio anterior ao reverb continua em processamento_reverb_deus/backup_e_hashes.json.
