# Pré-mixagem — como usar

Abra projetos_reaper/CenaXX_PREMIX.rpp ou execute python reconstruir_cenas.py. Necessita Python, NumPy, SciPy e FFmpeg já disponíveis no ambiente; não instala pacotes nem chama serviços.

Os WAVs individuais já têm os ganhos propostos. Ajuste volume por track/item no Reaper. Para nova renderização com o script, edite timeline_editavel.csv (start_frame) e ajustes_por_fala_db.json; as saídas vão para revisoes/, sem sobrescrever as prévias.

Não aplique pitch ou reverb em Deus: o WAV individual contém o Hall aprovado, com ganho de mixagem apenas. As caudas permanecem inteiras e podem soar sob a resposta seguinte, sem sobreposição de palavras. Intervals são provisórios; ainda não há sincronismo de animação.

Consulte RELATORIO_PREMIX.md para headroom e medições. Este material não é um master final YouTube.
