"""Renderizador portátil offline a partir dos WAVs individuais editáveis.
Uso: python reconstruir_cenas.py --cenas 1 23
Edite timeline_editavel.csv (start_frame) e ajustes_por_fala_db.json para revisões.
"""
from pathlib import Path
import argparse,json,csv,subprocess,datetime
import numpy as np
from scipy.io import wavfile
root=Path(__file__).resolve().parent
args=argparse.ArgumentParser();args.add_argument('--cenas',nargs='*',type=int);args=args.parse_args()
m=json.loads((root/'manifesto_mixagem.json').read_text());gains=json.loads((root/'ajustes_por_fala_db.json').read_text());sr=m['sample_rate']
with (root/'timeline_editavel.csv').open(encoding='utf-8-sig') as f:timeline={r['fala_id']:r for r in csv.DictReader(f)}
out=root/'revisoes'/datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ');out.mkdir(parents=True)
for scene in m['cenas']:
 if args.cenas and scene['cena'] not in args.cenas:continue
 clips=[];last=None
 for c in scene['clips']:
  fs,x=wavfile.read(root/c['stem_path']);assert fs==sr
  x=x.astype(np.float64)/2147483648
  if x.ndim==1:x=np.repeat(x[:,None],2,axis=1)
  pos=int(timeline[c['fala_id']]['start_frame']);assert pos>=0
  speech=c['end_speech_frame']-c['start_frame']
  if last:assert pos>=last,'Há sobreposição de palavras; revisar start_frame'
  last=pos+speech;clips.append((pos,x*10**(float(gains.get(c['fala_id'],0))/20)))
 n=max(scene['frames'],max(pos+len(x) for pos,x in clips));mix=np.zeros((n,2),np.float64)
 for pos,x in clips:mix[pos:pos+len(x)]+=x
 assert np.max(np.abs(mix))<1,'Ganho causa clipping: revisar ajustes'
 tmp=out/f'Cena{scene["cena"]:02}.float.wav';wavfile.write(tmp,sr,mix.astype(np.float32));wav=out/f'Cena{scene["cena"]:02}_PREMIX.wav'
 subprocess.run(['ffmpeg','-v','error','-nostdin','-i',str(tmp),'-codec:a','pcm_s24le',str(wav)],check=True);tmp.unlink()
 subprocess.run(['ffmpeg','-v','error','-nostdin','-i',str(wav),'-codec:a','libmp3lame','-b:a','192k',str(wav.with_suffix('.mp3'))],check=True)
 print(wav)
print('Reconstrução concluída sem alterar fontes ou prévias aprovadas.')
