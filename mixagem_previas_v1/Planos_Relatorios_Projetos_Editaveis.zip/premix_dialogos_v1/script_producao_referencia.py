"""Registro da produção original; os caminhos pertencem ao ambiente de origem.
Para uso portátil, execute o script reconstruir_* fornecido nesta pasta."""
"""Pré-mixagem local, reversível e editável. Sem rede, síntese, pitch ou reverb novo."""
from pathlib import Path
import json,hashlib,subprocess,re,csv,math,shutil
import numpy as np
from scipy.io import wavfile
from scipy.signal import resample_poly
p=Path(__file__).resolve().parent;root=p/'premix_dialogos_v1';cfg=json.loads((root/'config_mixagem.json').read_text());stats=json.loads((root/'medicoes_entrada.json').read_text());source=json.loads((p/'manifesto.json').read_text());sr=cfg['sample_rate'];t=cfg['perfis_temporais']
for directory in ['individuais_48k24','cenas_wav_48k24','cenas_mp3','previas','projetos_reaper','fontes_mp3/finais_aprovados','fontes_mp3/originais','fontes_mp3/deus_pitch_seco','stems_personagens']:(root/directory).mkdir(parents=True,exist_ok=True)
arrays={};byid={u['fala_id']:u for u in source['falas']}
for r in stats['fontes']:
 fs,x=wavfile.read(r['cache_wav']);assert fs==sr
 arrays[r['fala_id']]=x*10**((cfg['ganho_personagem_db'][r['personagem']]+cfg['ganhos_por_fala_db'].get(r['fala_id'],0))/20)
# Pausas só entre segmentos; reticências e respirações internas nunca são recortadas.
def pause_cues(scene,lo,hi):
 return [e for e in source['eventos_nao_falados'] if e['cena']==scene and lo<e['linha_fonte']<hi]
def gap_seconds(events,default):
 gap=default;why=[]
 for e in events:
  text=e['texto_fonte'].casefold()
  if 'longa pausa' in text:v=t['pausa_longa']
  elif 'breve pausa' in text or 'pausa musical breve' in text:v=t['pausa_breve']
  elif 'silêncio absoluto' in text or text in ('**silêncio.**','*silêncio.*'):v=t['silencio_explicito']
  elif 'pausa' in text or 'silêncio' in text or 'sem narração' in text:v=t['pausa_padrao']
  else:continue
  gap=max(gap,v);why.append({'evento_id':e['evento_id'],'linha_fonte':e['linha_fonte'],'pausa_referencia_segundos':v})
 return gap,why
scenes=[];allclips=[];scene_arrays={}
for scene in range(1,27):
 rows=[u for u in source['falas'] if u['cena']==scene];clips=[];previous=None;cursor=round(t['inicio_cena']*sr)
 for u in rows:
  x=arrays[u['fala_id']];events=[];why=[];gap=t['inicio_cena']
  if previous:
   events=pause_cues(scene,previous['linha_fonte'],u['linha_fonte'])
   if previous['personagem']==u['personagem']=='Narrador' and not events:default=t['mesmo_narrador_sem_acao']
   elif previous['personagem']==u['personagem']:default=t['mesmo_personagem']
   else:default=t['troca_personagem']
   if events:default=max(default,t['descoberta_ou_acao_visual'])
   gap,why=gap_seconds(events,default)
   cursor=clips[-1]['end_speech_frame']+round(gap*sr)
  # A duração seca de Deus vem do processamento aprovado; é menor que o arquivo com cauda.
  speech_frames=round(u.get('duracao_fala_segundos',len(x)/sr)*sr) if u['personagem']=='Deus' else len(x)
  speech_frames=min(speech_frames,len(x))
  clip={'fala_id':u['fala_id'],'cena':scene,'personagem':u['personagem'],'source_reference':u['arquivo_saida'],'input_sha256':hashlib.sha256((p/'audio'/u['arquivo_saida']).read_bytes()).hexdigest(),'start_frame':cursor,'end_speech_frame':cursor+speech_frames,'end_file_frame':cursor+len(x),'frames':len(x),'gap_before_segundos':gap,'pausas_roteiro':why,'intervalo_provisorio':True,'ganho_personagem_db':cfg['ganho_personagem_db'][u['personagem']],'overlap_somente_cauda':bool(previous and clips[-1]['end_file_frame']>cursor),'reverb_preservado':u['personagem']=='Deus','stem_path':f"individuais_48k24/cena_{scene:02}/"+u['fala_id']+'.wav'}
  if clips:assert cursor>=clips[-1]['end_speech_frame'],'Sobreposição de palavras não autorizada'
  clips.append(clip);previous=u
  if clips[-1]['overlap_somente_cauda']:assert clips[-2]['personagem']=='Deus'
 endevents=pause_cues(scene,rows[-1]['linha_fonte'],100000)
 endgap,endwhy=gap_seconds(endevents,t['fim_cena_sem_rubrica']);end=max(clips[-1]['end_speech_frame']+round(endgap*sr),max(c['end_file_frame'] for c in clips))
 mix=np.zeros((end,2),dtype=np.float32)
 for c in clips:mix[c['start_frame']:c['end_file_frame']]+=arrays[c['fala_id']]
 scene_arrays[scene]=mix
 tp=20*np.log10(max(float(np.max(np.abs(resample_poly(mix,4,1,axis=0)))),1e-15))
 scenes.append({'cena':scene,'titulo':next(x['titulo'] for x in source['cenas'] if x['cena']==scene),'sample_rate':sr,'frames':end,'duracao_segundos':end/sr,'clips':clips,'pausa_final_provisoria_segundos':endgap,'rubricas_pausa_final':endwhy,'true_peak_antes_headroom_dbtp':tp});allclips.extend(clips)
# Um único ganho global de segurança; mantém as diferenças expressivas das vozes.
maxpeak=max(s['true_peak_antes_headroom_dbtp'] for s in scenes);headroom_gain=min(0.0,cfg['teto_true_peak_wav_dbtp']-maxpeak);factor=10**(headroom_gain/20)
output_metrics=[]
def wav24(path,array,mono=False):
 path.parent.mkdir(parents=True,exist_ok=True)
 data=np.mean(array,axis=1) if mono else array
 raw=path.with_suffix('.float.wav');wavfile.write(raw,sr,data.astype(np.float32))
 subprocess.run(['ffmpeg','-v','error','-nostdin','-y','-i',str(raw),'-codec:a','pcm_s24le',str(path)],check=True);raw.unlink()
for c in allclips:
 u=byid[c['fala_id']];x=arrays[c['fala_id']]*factor;wav24(root/c['stem_path'],x,mono=u['personagem']!='Deus')
 c['ganho_global_headroom_db']=headroom_gain;c['ganho_total_db']=c['ganho_personagem_db']+cfg['ganhos_por_fala_db'].get(c['fala_id'],0)+headroom_gain
 for sub,src in [('finais_aprovados',p/'audio'/u['arquivo_saida']),('originais',p/'audio'/u['arquivo_bruto'])]:
  target=root/'fontes_mp3'/sub/f"cena_{u['cena']:02}"/src.name;target.parent.mkdir(exist_ok=True);shutil.copyfile(src,target)
 if u['personagem']=='Deus':
  dry=p/'audio'/u['arquivo_pitch_seco'];target=root/'fontes_mp3/deus_pitch_seco'/f"cena_{u['cena']:02}"/dry.name;target.parent.mkdir(exist_ok=True);shutil.copyfile(dry,target)
for s in scenes:
 i=s['cena'];mix=scene_arrays[i]*factor
 wav=root/f'cenas_wav_48k24/Cena{i:02}_PREMIX.wav';mp3=root/f'cenas_mp3/Cena{i:02}_PREMIX.mp3';wav24(wav,mix)
 subprocess.run(['ffmpeg','-v','error','-nostdin','-y','-i',str(wav),'-codec:a','libmp3lame','-b:a',cfg['mp3_bitrate'],str(mp3)],check=True)
 # Checagem estéreo/mono: diferença de loudness por energia e limite de pico.
 stereo_rms=float(np.sqrt(np.mean(mix.astype(np.float64)**2)));mono=np.mean(mix,axis=1);mono_rms=float(np.sqrt(np.mean(mono.astype(np.float64)**2)))
 mono_loss_db=20*np.log10(max(mono_rms,1e-15)/max(stereo_rms,1e-15));tp=s['true_peak_antes_headroom_dbtp']+headroom_gain
 r=subprocess.run(['ffmpeg','-hide_banner','-nostdin','-i',str(mp3),'-af','loudnorm=I=-23:TP=-6:LRA=11:print_format=json','-f','null','-'],capture_output=True,text=True,check=True)
 meter=json.loads(re.search(r'\{\s*"input_i".*?\}',r.stderr,re.S).group());assert tp<=-6 and float(meter['input_tp'])<=-6,'Headroom insuficiente';assert mono_loss_db>-3,'Cancelamento mono relevante'
 info=json.loads(subprocess.run(['ffprobe','-v','error','-show_entries','stream=codec_name,sample_rate,bits_per_raw_sample,channels:format=duration','-of','json',str(wav)],capture_output=True,text=True,check=True).stdout)
 assert info['streams'][0]['codec_name']=='pcm_s24le' and info['streams'][0]['sample_rate']=='48000'
 output_metrics.append({'cena':i,'duracao_segundos':s['duracao_segundos'],'true_peak_wav_dbtp':tp,'true_peak_mp3_dbtp':float(meter['input_tp']),'lufs_premix_estereo':float(meter['input_i']),'lra_lu':float(meter['input_lra']),'perda_mono_db':mono_loss_db,'wav':str(wav.relative_to(root)),'mp3':str(mp3.relative_to(root))})
 # Projeto de edição por cena; os WAV de itens já incorporam o ganho, portanto itens em unidade.
 rp=['<REAPER_PROJECT 0.1 7.0 1','  SAMPLERATE 48000','  TEMPO 120','  MASTER_VOLUME 1','  <NOTES','    |Pré-mixagem provisória. Sem sincronização visual definitiva. Somente caudas de Deus podem cruzar a fala seguinte.','  >']
 for role in dict.fromkeys(c['personagem'] for c in s['clips']):
  rp+=['  <TRACK',f'    NAME "{role}"','    VOLPAN 1 0 1 -1']
  for c in s['clips']:
   if c['personagem']!=role:continue
   rp+=['    <ITEM',f"      POSITION {c['start_frame']/sr:.9f}",f"      LENGTH {c['frames']/sr:.9f}",f"      NAME \"{c['fala_id']}\"",'      VOLPAN 1 0 1 -1','      SOFFS 0','      <SOURCE WAVE',f"        FILE \"../{c['stem_path']}\"",'      >','    >']
  rp+=['  >']
 rp+=['>'];(root/f'projetos_reaper/Cena{i:02}_PREMIX.rpp').write_text('\n'.join(rp)+'\n')
 print(f'CENA {i:02}: {len(s["clips"])} falas, {s["duracao_segundos"]:.2f}s, pico WAV {tp:.2f} dBTP, mono {mono_loss_db:.3f} dB',flush=True)
# Duas prévias, sem nova geração. B cobre a decisão emocional na Cena 23.
for scene,label in [(1,'A_Cena01'),(23,'B_Conversa_Deus_Cena23')]:
 shutil.copyfile(root/f'cenas_mp3/Cena{scene:02}_PREMIX.mp3',root/f'previas/Previa_{label}.mp3');shutil.copyfile(root/f'cenas_wav_48k24/Cena{scene:02}_PREMIX.wav',root/f'previas/Previa_{label}.wav')
manifest={'modo':'premix_dialogos_sem_sintese','sample_rate':sr,'bit_depth':24,'fontes_finais_aprovadas':125,'faltantes':[],'cenas':scenes,'ganho_global_headroom_db':headroom_gain,'ganhos_personagem_db':cfg['ganho_personagem_db'],'eq_compressao_deesser_ruido_aplicados':False,'pitch_velocidade_reverb_reaplicados':False,'tempos_provisorios':True,'loudness_final_youtube_aplicado':False,'creditos_elevenlabs':0,'metricas_saida':output_metrics}
(root/'manifesto_mixagem.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
with (root/'timeline_editavel.csv').open('w',encoding='utf-8-sig',newline='') as f:
 fields=['fala_id','cena','personagem','start_frame','end_speech_frame','end_file_frame','frames','gap_before_segundos','overlap_somente_cauda','ganho_personagem_db','ganho_global_headroom_db','ganho_total_db','stem_path'];w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(allclips)
checks=json.loads((root/'inspecao_fontes.json').read_text())
for r in checks['fontes']:
 assert hashlib.sha256(Path(r['source_path']).read_bytes()).hexdigest()==r['source_sha256'];assert hashlib.sha256(Path(r['raw_path']).read_bytes()).hexdigest()==r['raw_sha256']
print('PREMIX_CONCLUIDA',len(scenes),len(allclips),'ganho_global',headroom_gain,flush=True)
