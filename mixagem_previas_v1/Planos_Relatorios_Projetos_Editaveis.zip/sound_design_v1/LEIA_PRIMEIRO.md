# Três demonstrações — como usar

Comece pela Prévia C, seguida por A e B. Todos os MP3 em audio/previews/. Música-guia original, não trilha definitiva.

Abra os projetos Reaper em projetos/ ou execute python reconstruir_previas.py para somar os stems em nova pasta revisoes/. Edite ajustes_stems.json para testar balanços. Os stems DX, AMB, FX e MX já incluem a automação documentada; não reaplique ducking nem efeitos à voz de Deus.

Para retrabalhar palavras e pausas individualmente, use o pacote de pré-mixagem e substitua o stem DX pela nova montagem. O MIDI e o JSON em audio/musicas/guias/ permitem reorquestrar as composições originais com instrumentos de qualidade. Automação e marcadores permanecem provisórios até o animatic.

Após entregar estas três demonstrações, a finalização completa foi interrompida para avaliação. Nenhum recurso externo foi comprado, baixado ou licenciado nesta etapa.
