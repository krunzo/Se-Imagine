Finalização da sonorização completa suspensa para avaliação das três demonstrações. Música é composição-guia, não trilha instrumental definitiva.
