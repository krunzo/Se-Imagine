"""Registro da produção original; os caminhos pertencem ao ambiente de origem.
Para uso portátil, execute o script reconstruir_* fornecido nesta pasta."""
"""Três demonstrações locais: síntese procedural original e música-guia editável.
Não usa rede, ElevenLabs, amostras externas nem masterização final para YouTube.
"""
from pathlib import Path
import json,subprocess,struct,re,csv,math,shutil,copy
import numpy as np
from scipy import signal
from scipy.io import wavfile
p=Path(__file__).resolve().parent;root=p/'sound_design_v1';premix=p/'premix_dialogos_v1';pm=json.loads((premix/'manifesto_mixagem.json').read_text());script=json.loads((p/'manifesto.json').read_text());byid={u['fala_id']:u for u in script['falas']};sr=48000;rng=np.random.default_rng(20261104)
for d in ['audio/dialogos','audio/ambientes','audio/efeitos','audio/musicas/guias','audio/stems','audio/premixes','audio/previews','audio/final','projetos','assets_float','automacoes']:(root/d).mkdir(parents=True,exist_ok=True)
(root/'audio/final/NAO_FINALIZADO.md').write_text('Finalização da sonorização completa suspensa para avaliação das três demonstrações. Música é composição-guia, não trilha instrumental definitiva.\n')
def db(value):return 10**(value/20)
def smooth(x):return x*x*(3-2*x)
def noise(duration,lo,hi,seed):
 g=np.random.default_rng(seed);n=round(duration*sr);data=g.normal(size=(n,2)).astype(np.float32)
 sos=signal.butter(2,[lo,hi],btype='bandpass',fs=sr,output='sos');data=signal.sosfilt(sos,data,axis=0).astype(np.float32)
 data/=max(float(np.sqrt(np.mean(data.astype(np.float64)**2))),1e-9);return data
assets={}
assets['chuva']=noise(20,300,9000,1)
# Camadas de água diferentes da chuva, com modulação lenta e estéreo difuso.
a=noise(20,50,1300,2);tt=np.arange(len(a))/sr;a*=((.75+.15*np.sin(tt*.8)+.1*np.sin(tt*2.3))[:,None]);assets['correnteza']=a
fire=noise(20,90,4700,3)*.72
for _ in range(140):
 pos=int(rng.uniform(0,len(fire)-sr*.06));n=int(rng.uniform(.006,.045)*sr);x=rng.normal(size=(n,2)).astype(np.float32)*np.exp(-np.arange(n)[:,None]/(n*.22));fire[pos:pos+n]+=x*float(rng.uniform(.6,1.8))
fire/=max(float(np.sqrt(np.mean(fire.astype(np.float64)**2))),1e-9);assets['fogo']=fire
x=noise(4,28,900,4);t=np.arange(len(x))/sr;env=(1-np.exp(-t/.025))*np.exp(-t/1.0);x*=env[:,None];x/=max(float(np.max(np.abs(x))),1e-9);assets['trovao']=x
x=noise(1,140,7500,5);t=np.arange(len(x))/sr;x*=((1-np.exp(-t/.008))*np.exp(-t/.13))[:,None];x/=max(float(np.max(np.abs(x))),1e-9);assets['respingo']=x
# Textura celestial evita médios da voz: ar alto + corpo baixo, em nível muito discreto.
assets['celestial']=.75*noise(24,6200,10000,6)+.25*noise(24,70,170,7)
# Assinatura única e discreta dos milagres, sem biblioteca de videogame.
n=round(1.4*sr);t=np.arange(n)/sr;mir=np.zeros((n,2),dtype=np.float32)
for freq,offset in [(587.33,0),(659.25,.16),(880,.29)]:
 q=np.maximum(t-offset,0);e=(1-np.exp(-q/.12))*np.exp(-q/.30)*(t>=offset);v=.35*np.sin(2*np.pi*freq*q)*e
 mir[:,0]+=v;mir[:,1]+=v*.95
mir+=noise(1.4,4500,9000,8)*(.008*np.exp(-t/.5))[:,None];mir/=max(float(np.max(np.abs(mir))),1e-9);assets['milagre']=mir
for name,x in assets.items():wavfile.write(root/'assets_float'/f'{name}_ORIGINAL_PROCEDURAL.wav',sr,x)
def wav24(path,x):
 path.parent.mkdir(exist_ok=True,parents=True);temp=path.with_suffix('.float.wav');wavfile.write(temp,sr,x.astype(np.float32));subprocess.run(['ffmpeg','-v','error','-nostdin','-y','-i',str(temp),'-codec:a','pcm_s24le',str(path)],check=True);temp.unlink()
for name,x in assets.items():
 dest=root/('audio/ambientes' if name in ['chuva','correnteza','fogo','celestial'] else 'audio/efeitos')/(name+'_ORIGINAL_PROCEDURAL.wav')
 wav24(dest,x*.12)
def add(dest,x,start,gain=1):
 pos=max(0,round(start*sr));count=min(len(x),len(dest)-pos)
 if count>0:dest[pos:pos+count]+=x[:count]*gain
def tiled(name,duration,level):
 src=assets[name];n=round(duration*sr);data=np.tile(src,(math.ceil(n/len(src)),1))[:n].copy();fade=min(round(.5*sr),n//3);data[:fade]*=smooth(np.linspace(0,1,fade))[:,None];data[-fade:]*=smooth(np.linspace(1,0,fade))[:,None]
 return data*db(level)
def region(env,a,b,value,attack=.15,release=.5):
 # Atenuação mínima entre envelopes concorrentes; sem compressor de diálogo.
 aa=max(0,round((a-attack)*sr));ab=max(0,round(a*sr));ba=min(len(env),round(b*sr));bb=min(len(env),round((b+release)*sr))
 if ab>aa:env[aa:ab]=np.minimum(env[aa:ab],1-(1-value)*smooth(np.linspace(0,1,ab-aa)))
 if ba>ab:env[ab:ba]=np.minimum(env[ab:ba],value)
 if bb>ba:env[ba:bb]=np.minimum(env[ba:bb],value+(1-value)*smooth(np.linspace(0,1,bb-ba)))
def make_timeline(scene_numbers):
 clips=[];sc=[];offset=0
 for i in scene_numbers:
  s=next(s for s in pm['cenas'] if s['cena']==i);fs,x=wavfile.read(premix/f'cenas_wav_48k24/Cena{i:02}_PREMIX.wav');assert fs==sr
  # scipy lê PCM24 em int32 left-justified.
  x=x.astype(np.float32)/2147483648
  if i==1:
   # Janela provisória para o raio depois do resgate, seguida de silêncio; não sincronismo definitivo.
   x=np.pad(x,((0,3*sr),(0,0)));s=copy.deepcopy(s);s['frames']=len(x);s['duracao_segundos']=len(x)/sr
  sc.append({'cena':i,'offset':offset/sr,'frames':len(x),'duracao':len(x)/sr,'data':x,'source':s})
  for c in s['clips']:
   cc=dict(c);cc.update({'start_sec':(offset+c['start_frame'])/sr,'end_speech_sec':(offset+c['end_speech_frame'])/sr,'end_file_sec':(offset+c['end_file_frame'])/sr,'texto':byid[c['fala_id']]['texto_exato']});clips.append(cc)
  offset+=len(x)+round(.30*sr)
 n=offset-round(.30*sr);dx=np.zeros((n,2),np.float32)
 for s in sc:add(dx,s['data'],s['offset'])
 return dx,clips,sc
notes=[]
def note(instrument,start,duration,midi,velocity,theme):
 notes.append({'instrumento':instrument,'inicio_segundos':float(start),'duracao_segundos':float(duration),'nota_midi':int(midi),'velocidade':int(velocity),'tema':theme})
def midi_file(path,note_list,bpm=60):
 def vlq(n):
  b=[int(n)&127];n=int(n)>>7
  while n:b.insert(0,(n&127)|128);n>>=7
  return bytes(b)
 def track(events):
  events.sort(key=lambda x:(x[0],x[1]));out=b'';last=0
  for tick,_,data in events:out+=vlq(tick-last)+data;last=tick
  out+=b'\x00\xff\x2f\x00';return b'MTrk'+struct.pack('>I',len(out))+out
 tempo=round(60000000/bpm);tracks=[track([(0,0,b'\xff\x51\x03'+tempo.to_bytes(3,'big'))])]
 for channel,(inst,program) in enumerate([('piano_guia',0),('cordas_guia',48),('baixo_guia',32)]):
  events=[(0,0,bytes([0xC0+channel,program]))]
  for v in note_list:
   if v['instrumento']!=inst:continue
   a=round(v['inicio_segundos']*bpm*480/60);b=round((v['inicio_segundos']+v['duracao_segundos'])*bpm*480/60)
   events.extend([(a,1,bytes([0x90+channel,v['nota_midi'],v['velocidade']])),(b,0,bytes([0x80+channel,v['nota_midi'],0]))])
  tracks.append(track(events))
 path.write_bytes(b'MThd'+struct.pack('>IHHH',6,1,len(tracks),480)+b''.join(tracks))
def render_notes(count,note_list):
 output=np.zeros((count,2),np.float32)
 for v in note_list:
  duration=min(v['duracao_segundos']+1.5,7);n=round(duration*sr);t=np.arange(n)/sr;f=440*2**((v['nota_midi']-69)/12);vel=v['velocidade']/127
  if v['instrumento']=='piano_guia':
   x=np.zeros(n)
   for k in range(1,9):x+=np.sin(2*np.pi*f*k*np.sqrt(1+.00012*k*k)*t)/(k**1.7)*np.exp(-t/(2.4/(1+k*.45)))
   x*=(1-np.exp(-t/.012))*np.exp(-np.maximum(t-v['duracao_segundos'],0)/.45)
  elif v['instrumento']=='cordas_guia':
   x=np.zeros(n)
   for k in range(1,6):x+=np.sin(2*np.pi*f*k*t+.002*np.sin(t*3))/(k**2.2)
   x*=np.minimum(t/.9,1)*np.exp(-np.maximum(t-v['duracao_segundos'],0)/1.0)
  else:x=np.sin(2*np.pi*f*t)*(1-np.exp(-t/.18))*np.exp(-np.maximum(t-v['duracao_segundos'],0)/.5)*.45
  x=x*vel*.12;st=np.stack([x,x*.985],axis=1).astype(np.float32);add(output,st,v['inicio_segundos'])
 return output
previews=[('A_Tempestade_Descoberta',[1,2]),('B_Incendio_Resgate',[8,9,10]),('C_Conversa_Deus_PRIORITARIA',[19,20,21,22,23,24])];summaries=[];automation_rows=[];allnotes={}
for label,scenes in previews:
 dx,clips,sceneinfo=make_timeline(scenes);n=len(dx);duration=n/sr;amb=np.zeros_like(dx);fx=np.zeros_like(dx);notes=[];markers=[]
 byclip={c['fala_id']:c for c in clips};scene_by={s['cena']:s for s in sceneinfo}
 if label.startswith('A'):
  amb+=tiled('chuva',duration,-34)+tiled('correnteza',duration,-39)
  first=scene_by[1];f2=scene_by[2]
  add(fx,assets['respingo'],byclip['cena_01_fala_005']['start_sec']-.4,db(-29))
  # O trovão precede o silêncio final da cena, em timing expressamente provisório.
  thunder=byclip['cena_01_fala_006']['end_speech_sec']+.12;add(fx,assets['trovao'],thunder,db(-21));markers.append({'ponto':'raio/trovao provisório','tempo':thunder,'referencia':'fim da Cena 01; ajustar à animação'})
  freeze=byclip['cena_02_fala_002']['start_sec'];resume=byclip['cena_02_fala_003']['end_speech_sec'];region(np.ones(n),freeze,resume,0)
  mask=np.ones(n,np.float32);region(mask,freeze,resume,0,.25,.35);amb*=mask[:,None]
  cure=byclip['cena_02_fala_003']['start_sec']-.2;add(fx,assets['milagre'],cure,db(-33));markers.append({'ponto':'cura','tempo':cure,'referencia':'ferimento desaparece; timing provisório'})
  for t0,midi in [(1.8,50),(9.8,57),(f2['offset']+2,62),(duration-3,64)]:note('piano_guia',t0,2,midi,38,'Ruptura/Compaixao')
  note('baixo_guia',0,6,38,28,'Ruptura')
 elif label.startswith('B'):
  burn=byclip['cena_08_fala_003']['end_speech_sec']+.05
  flame=tiled('fogo',duration,-34);fadein=np.zeros(n,np.float32);startburn=round(burn*sr);fadein[startburn:]=1
  fadein[startburn:startburn+round(.3*sr)]=smooth(np.linspace(0,1,round(.3*sr)));amb+=flame*fadein[:,None]
  water=tiled('correnteza',duration,-42);wmask=np.ones(n,np.float32);region(wmask,burn,duration,0,.6,.1);amb+=water*wmask[:,None]
  endfire=scene_by[9]['offset']+.35;fade=np.ones(n,np.float32);region(fade,endfire,duration,0,.7,.1);amb*=fade[:,None]
  for t0 in [2.2,8.1,15.7]:add(fx,assets['respingo'],t0,db(-36))
  for uid in ['cena_09_fala_003']:
   add(fx,assets['milagre'],byclip[uid]['end_speech_sec']+.1,db(-35))
  add(fx,assets['milagre'],byclip['cena_10_fala_002']['start_sec'],db(-37))
  for t0 in np.arange(1,scene_by[10]['offset'],6):
   note('piano_guia',t0,1.2,50 if int(t0//6)%2==0 else 51,30,'Ruptura');note('baixo_guia',t0,2.5,38,22,'Ruptura')
 else:
  amb+=tiled('celestial',duration,-49)
  # Encontro: quase silêncio. Questionamentos: notas inquietas somente nos espaços de Will.
  for c in clips:
   if c['cena'] in (19,20) and c['personagem']=='Protagonista':
    if c['fala_id']!='cena_19_fala_001':note('piano_guia',c['end_speech_sec']+.2,1.4,62 if c['cena']==19 else 63,26,'Sacrificio/Ruptura')
  for scene in [19,20,21]:
   o=scene_by[scene]['offset'];note('cordas_guia',o+.7,min(6,scene_by[scene]['duracao']-1),50,18,'Sacrificio')
  start=byclip['cena_22_fala_001']['start_sec'];end=scene_by[23]['offset']
  for j,t0 in enumerate(np.arange(start,end,7.5)):note('piano_guia',t0,2.3,[62,64,69,65][j%4],32,'Sacrificio')
  choice=byclip['cena_23_fala_013']['start_sec'];surrender=byclip['cena_23_fala_016']['start_sec']
  for j,t0 in enumerate(np.arange(choice,surrender,3.8)):
   note('piano_guia',t0,2.3,[62,64,69,65,64][j%5],34+j*2,'Sacrificio')
   if j>0:note('cordas_guia',t0,3.2,[50,57,62][j%3],22+j,'Sacrificio')
  # Desfecho mostra esperança sutil, não apoteose; silêncio físico da Cena 24 preservado abaixo.
  o=scene_by[24]['offset'];note('piano_guia',o+.1,1.8,66,28,'Sacrificio_para_Compaixao');note('piano_guia',o+1.2,2.0,69,23,'Sacrificio_para_Compaixao')
  for uid,phase in [('cena_19_fala_001','Encontro quase silencioso'),('cena_20_fala_007','Questionamento'),('cena_21_fala_002','Revelação de Deus'),('cena_22_fala_001','Vulnerabilidade'),('cena_23_fala_009','Medo da morte'),('cena_23_fala_012','Desejo de viver / pausa longa'),('cena_23_fala_013','Crescendo contido'),('cena_23_fala_016','Entrega e silêncio de Deus'),('cena_24_fala_001','Consequência e esperança')]:
   c=byclip[uid];markers.append({'fase':phase,'fala_id':uid,'texto_exato':c['texto'],'tempo':c['start_sec']})
  # Não atacar notas novas dentro de revelações de Deus ou no silêncio após a entrega.
  def allowed(v):
   start=v['inicio_segundos']
   if any(c['personagem']=='Deus' and c['start_sec']<=start<=c['end_speech_sec'] for c in clips):return v['instrumento']=='cordas_guia'
   return not (byclip['cena_23_fala_016']['end_speech_sec']<=start<scene_by[24]['offset'])
  notes=[v for v in notes if allowed(v)]
 music=render_notes(n,notes)
 rms=float(np.sqrt(np.mean(music.astype(np.float64)**2)))
 if rms>0:music*=db(-35 if not label.startswith('C') else -37)/rms
 music_env=np.ones(n,np.float32);amb_env=np.ones(n,np.float32);fx_env=np.ones(n,np.float32)
 for c in clips:
  isgod=c['personagem']=='Deus';start=c['start_sec'];end=c['end_file_sec'] if isgod else c['end_speech_sec']
  duck=-18 if isgod else -8
  region(music_env,start,end,db(duck),.18,1.0 if isgod else .55);region(amb_env,start,end,db(-7 if isgod else -4),.12,.55);region(fx_env,start,c['end_speech_sec'],db(-4),.06,.3)
  automation_rows.append({'previa':label,'fala_id':c['fala_id'],'inicio':start,'fim_fala':c['end_speech_sec'],'fim_arquivo_com_cauda':c['end_file_sec'],'duck_music_db':duck,'cauda_deus_protegida':isgod})
 # Respeitar pausas e silêncios: só vozes/caudas existentes permanecem, sem preencher com música.
 silence=np.ones(n,np.float32)
 for s in sceneinfo:
  ss=s['source'];offset=s['offset']
  for k,c in enumerate(ss['clips']):
   if not c['pausas_roteiro'] or k==0:continue
   prev=ss['clips'][k-1];a=offset+prev['end_speech_frame']/sr;b=offset+c['start_frame']/sr
   if b>a:region(silence,a,b,0,.08,.18)
  if ss['rubricas_pausa_final']:
   a=offset+ss['clips'][-1]['end_speech_frame']/sr;b=offset+ss['frames']/sr
   if s['cena']==1:a=b-1.0
   region(silence,a,b,0,.12,.1)
 if label.startswith('B'):
  a=scene_by[10]['offset'];region(music_env,a,duration,0,.3,.1)
 if label.startswith('C'):
  # Medo: o sentimento fica nas vozes, não num colchão musical permanente.
  a=byclip['cena_23_fala_009']['start_sec'];b=byclip['cena_23_fala_011']['end_file_sec'];region(music_env,a,b,db(-20),.6,.8)
  a=byclip['cena_23_fala_016']['end_speech_sec'];b=scene_by[24]['offset'];region(silence,a,b,0,.15,.2)
 music*=music_env[:,None]*silence[:,None];amb*=amb_env[:,None]*silence[:,None];fx*=fx_env[:,None]*silence[:,None]
 mix=dx+music+amb+fx
 peak=20*np.log10(max(float(np.max(np.abs(signal.resample_poly(mix,4,1,axis=0)))),1e-12));gain=min(0,-4.5-peak);g=db(gain)
 # Stems pré-bus sem alterar DX; o ganho de bus é registrado para reconstrução da prévia.
 for stem,arr in [('DX_dialogos',dx),('AMB_ambientes',amb),('FX_efeitos',fx),('MX_musica_GUIA',music)]:wav24(root/'audio/stems'/label/(stem+'.wav'),arr)
 wav=root/'audio/premixes'/(label+'_DEMONSTRACAO_GUIA.wav');mp3=root/'audio/previews'/(label+'_DEMONSTRACAO_GUIA.mp3');wav24(wav,mix*g)
 subprocess.run(['ffmpeg','-v','error','-nostdin','-y','-i',str(wav),'-codec:a','libmp3lame','-b:a','192k',str(mp3)],check=True)
 # Exportação mono de conferência, não substitui a estéreo.
 mono=np.mean(mix*g,axis=1);wav24(root/'audio/premixes'/(label+'_MONO_CHECK.wav'),np.repeat(mono[:,None],2,axis=1))
 measured=subprocess.run(['ffmpeg','-hide_banner','-nostdin','-i',str(mp3),'-af','loudnorm=I=-23:TP=-3:LRA=11:print_format=json','-f','null','-'],capture_output=True,text=True,check=True)
 meter=json.loads(re.search(r'\{\s*"input_i".*?\}',measured.stderr,re.S).group());assert float(meter['input_tp'])<=-3
 rmsst=float(np.sqrt(np.mean((mix*g).astype(np.float64)**2)));rmsmono=float(np.sqrt(np.mean(mono.astype(np.float64)**2)));mono_loss=20*np.log10(max(rmsmono,1e-12)/max(rmsst,1e-12));assert mono_loss>-3
 midi_file(root/'audio/musicas/guias'/(label+'_COMPOSICAO_ORIGINAL_GUIA.mid'),notes)
 (root/'audio/musicas/guias'/(label+'_PARTITURA_EDITAVEL.json')).write_text(json.dumps({'bpm':60,'status':'composicao_guia_nao_trilha_definitiva','notas':notes},ensure_ascii=False,indent=2)+'\n')
 # Projeto com quatro trilhas e automações incorporadas aos stems, sem FX nos diálogos.
 rp=['<REAPER_PROJECT 0.1 7.0 1','  SAMPLERATE 48000',f'  MASTER_VOLUME {g:.12f}']
 for stem in ['DX_dialogos','AMB_ambientes','FX_efeitos','MX_musica_GUIA']:
  file=f'../audio/stems/{label}/{stem}.wav';rp+=['  <TRACK',f'    NAME "{stem}"','    VOLPAN 1 0 1 -1','    <ITEM','      POSITION 0',f'      LENGTH {duration:.9f}','      VOLPAN 1 0 1 -1','      <SOURCE WAVE',f'        FILE "{file}"','      >','    >','  >']
 rp+=['>'];(root/'projetos'/(label+'.rpp')).write_text('\n'.join(rp)+'\n')
 desc={'previa':label,'cenas':scenes,'duracao_segundos':duration,'bus_gain_db':gain,'true_peak_mp3_dbtp':float(meter['input_tp']),'lufs_medidos_nao_alvo_final':float(meter['input_i']),'perda_mono_db':mono_loss,'marcadores_narrativos':markers,'musica_guia_original':True,'numero_notas':len(notes),'wav':str(wav.relative_to(root)),'mp3':str(mp3.relative_to(root)),'dialogos_reprocessados':False,'credito_elevenlabs':0};summaries.append(desc)
 print('PREVIA',label,round(duration,2),'s; pico',meter['input_tp'],'mono',round(mono_loss,3),'dB',flush=True)
(root/'manifesto_previas.json').write_text(json.dumps({'previas':summaries,'finalizacao_completa_suspensa_para_avaliacao':True,'licencas_externas_utilizadas':False,'geracao_elevenlabs':False},ensure_ascii=False,indent=2)+'\n')
with (root/'automacoes/ducking_e_falas.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(automation_rows[0]));w.writeheader();w.writerows(automation_rows)
print('TRES_PREVIAS_CONCLUIDAS. Sonorização definitiva interrompida para avaliação.',flush=True)
