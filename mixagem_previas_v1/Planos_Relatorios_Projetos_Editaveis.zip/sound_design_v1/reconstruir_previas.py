"""Reconstrução portátil das três prévias a partir de DX/AMB/FX/MX.
Uso: python reconstruir_previas.py --previa C
O ducking já está nos stems. Não reaplica pitch, reverb, EQ ou compressão.
"""
from pathlib import Path
import json,argparse,subprocess,datetime
import numpy as np
from scipy.io import wavfile
root=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--previa',choices=['A','B','C']);args=parser.parse_args()
m=json.loads((root/'manifesto_previas.json').read_text());g=json.loads((root/'ajustes_stems.json').read_text());out=root/'revisoes'/datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ');out.mkdir(parents=True)
for preview in m['previas']:
 label=preview['previa']
 if args.previa and not label.startswith(args.previa+'_'):continue
 mix=None
 for name in ['DX_dialogos','AMB_ambientes','FX_efeitos','MX_musica_GUIA']:
  fs,x=wavfile.read(root/'audio/stems'/label/(name+'.wav'));assert fs==48000
  x=x.astype(np.float64)/2147483648
  if mix is None:mix=np.zeros_like(x)
  assert len(mix)==len(x)
  mix+=x*10**(float(g.get(name,0))/20)
 mix*=10**(preview['bus_gain_db']/20);assert np.max(np.abs(mix))<1,'Clipping: reduzir ganho dos stems'
 tmp=out/(label+'.float.wav');wavfile.write(tmp,fs,mix.astype(np.float32));wav=out/(label+'_REVISAO.wav')
 subprocess.run(['ffmpeg','-v','error','-nostdin','-i',str(tmp),'-codec:a','pcm_s24le',str(wav)],check=True);tmp.unlink()
 subprocess.run(['ffmpeg','-v','error','-nostdin','-i',str(wav),'-codec:a','libmp3lame','-b:a','192k',str(wav.with_suffix('.mp3'))],check=True)
 print(wav)
print('Prévia reconstruída. Música continua sendo guia; nada foi finalizado para YouTube.')
