# Cena 01 — Resultado definitivo

Exatamente seis solicitações de síntese; uma versão por segmento. Custo reportado pela API: **116 créditos**, teto autorizado 293. Nenhuma outra cena gerada.

| Segmento | Personagem | Modelo | Duração do áudio | Créditos |
|---|---|---|---:|---:|
| cena_01_fala_001 | Narrador | eleven_multilingual_v2 | 2.740 s | 16 |
| cena_01_fala_002 | Narrador | eleven_multilingual_v2 | 5.619 s | 34 |
| cena_01_fala_003 | Narrador | eleven_multilingual_v2 | 1.811 s | 12 |
| cena_01_fala_004 | Pedestre | eleven_v4_turbo | 2.240 s | 6 |
| cena_01_fala_005 | Narrador | eleven_multilingual_v2 | 3.344 s | 20 |
| cena_01_fala_006 | Narrador | eleven_multilingual_v2 | 4.551 s | 28 |

Originais em `audio/cena_01/raw/`; arquivos finais em `audio/cena_01/`. Leonardo recebeu −1 semitom com tempo 1; André foi copiado sem alterações de pitch. A duração foi verificada pelo número de amostras PCM decodificadas, idêntico entre cada original e final. A duração do contêiner MP3 pode incluir padding do codec e diferir dessa medida.

Os corpos das seis solicitações preservam o texto aprovado. Conferidos decodificação completa, duração e separação dos arquivos. Não houve falha de síntese, retry ou geração de variante. André foi vinculado à conta antes da síntese. Nenhum problema técnico detectado nesses controles; a interpretação e a dicção ainda devem ser ouvidas na revisão artística.

Este relatório substitui o estado de preparação da Cena 01. As cenas 02–26 continuam sem autorização de síntese.
